'use strict';
var alexaSDK = require('alexa-sdk');
var Client = require('node-rest-client').Client;
// var client = new Client();

const
    REPROMPT = 'For assistance just say \'Help Me\'.',
    SKILL = 'gif gaff from DAG team'; // for pronunciation

exports.handler = function(event, context){
    var alexa = alexaSDK.handler(event, context);
    alexa.registerHandlers(handlers);
    alexa.execute();
};

// var args = {
//     headers: { "auth_email": "qawsedstation@gmail.com",'auth_password' : 'qawsed' }// request headers
// };

var handlers = {
    'LaunchRequest': function () {
        this.emit(':ask', 'Welcome to ' + SKILL + '. How can I help?', REPROMPT);
    },
    // 'CurrentOrderIntent': function () {
    //
    //     var that = this;
    //     client.get("http://gopospro.com:3030/orders/pending",args, function (data, response) {
    //
    //         that.emit(':tell', JSON.stringify(response) + JSON.stringify(data));
    //     });
    // },

    'AMAZON.HelpIntent': function () {
        this.emit(':ask', '<p>Here are some things you can say:</p><p>Make me a giff gaffer</p><p>Order giff gaff sim card?</p><p>What bundles are available?</p><p>So how can I help?</p>', REPROMPT);
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', 'Goodbye.');
    },
    'Unhandled': function () {
        this.emit(':ask', 'Yikes! Something went wrong.');
    }
};

